# ODcheat 2.6.0 — изменения

- Название приложения и launcher label: ODcheat.
- Новый логотип ODcheat в launcher icon и экранах приложения.
- Новый applicationId: `com.odcheat.launcher`.
- В галерею добавлены 4 образа: Crimson Vanguard, Ruby Shadow, Silver Dragon, Frost Guardian.
- Выбор образа сохраняется через существующий SettingsRepository/DataStore.
- Исходные изображения сохранены в `artwork/character-sheets/`; оптимизированные preview-файлы находятся в `app/src/main/res/drawable-nodpi/`.
- Увеличение размера проекта сделано за счёт реальных изображений и исходников, не за счёт пустых файлов.

Примечание: изображения являются арт-превью для галереи приложения. Они не являются текстурами/моделями игрового формата и не применяются к персонажу OXIDE без официального API игры.
